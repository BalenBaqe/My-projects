import javax.swing.*;
import java.awt.*;

public class FontChooserDialog extends JDialog {
    private Font selectedFont;

    public FontChooserDialog(Frame owner, Font initialFont) {
        super(owner, "Choose Font", true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        final JList<String> fontList = new JList<>(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
        fontList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        fontList.setSelectedValue(initialFont.getFamily(), true);
        JScrollPane fontScrollPane = new JScrollPane(fontList);

        final JList<Integer> sizeList = new JList<>(new Integer[]{8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 48, 56, 64, 72, 92, 100, 200, 300});
        sizeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sizeList.setSelectedValue(initialFont.getSize(), true);
        JScrollPane sizeScrollPane = new JScrollPane(sizeList);

        JPanel controlPanel = new JPanel(new FlowLayout());

        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> {
            String selectedFontName = fontList.getSelectedValue();
            int selectedFontSize = sizeList.getSelectedValue();
            if (selectedFontName != null && selectedFontSize != 0) {
                selectedFont = new Font(selectedFontName, Font.PLAIN, selectedFontSize);
                dispose();
            } else {
                JOptionPane.showMessageDialog(FontChooserDialog.this, "Please select a font and size.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> {
            selectedFont = null;
            dispose();
        });

        controlPanel.add(okButton);
        controlPanel.add(cancelButton);

        add(fontScrollPane, BorderLayout.WEST);
        add(sizeScrollPane, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    public Font getSelectedFont() {
        return selectedFont;
    }
}
