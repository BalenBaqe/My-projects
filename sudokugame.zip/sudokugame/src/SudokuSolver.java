public class SudokuSolver {
    private final int SIZE = 9; // Size of the Sudoku puzzle
    private final int BOX_SIZE = 3; // Size of each box in the Sudoku puzzle
    private int[][] board; // 2D array representing the Sudoku puzzle
    private int iterationCount = 0; // Number of iterations performed during solving

    public SudokuSolver(int[][] board) {
        this.board = board; // Initialize the Sudoku puzzle board
    }

    public void solve() {
        long startTime = System.nanoTime(); // Start measuring execution time

        if (dfs()) {
            System.out.println("Solution found:");
            printBoard(); // Print the solved Sudoku puzzle
        } else {
            System.out.println("No solution found.");
            printBoard(); // Print the current state of the Sudoku puzzle
        }

        long duration = (System.nanoTime() - startTime) / 1_000_000; // Calculate the duration in milliseconds
        System.out.println("Total iterations: " + iterationCount);
        System.out.println("It took " + duration + "ms");
    }

    public boolean dfs() {

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (board[row][col] == 0) { // If the cell is empty
                    for (int num = 1; num <= SIZE; num++) {
                        iterationCount++;
                        if (isValidMove(row, col, num)) {
                            board[row][col] = num; // Make a move by placing a number

                            if (dfs()) {
                                return true; // Move successful, continue solving
                            }

                            board[row][col] = 0; // Undo the move (backtrack)
                        }
                    }
                    return false; // No valid move found, backtrack
                }
            }
        }

        return true; // All cells filled (solution found)
    }

    public int[][] getHint() {
        dfs();
        return board; // Return the solved Sudoku puzzle
    }

    private boolean isValidMove(int row, int col, int value) {
        // Check row and column for conflicts
        for (int i = 0; i < SIZE; i++) {
            if (board[row][i] == value || board[i][col] == value) {
                return false; // Conflict found
            }
        }

        // Check box for conflicts
        int boxRow = row / BOX_SIZE * BOX_SIZE; // Find the index of the box
        int boxCol = col / BOX_SIZE * BOX_SIZE; // Find the index of the box

        for (int i = boxRow; i < boxRow + BOX_SIZE; i++) {
            for (int j = boxCol; j < boxCol + BOX_SIZE; j++) {
                if (board[i][j] == value) {
                    return false; // Conflict found
                }
            }
        }

        return true; // No conflicts found
    }

    public void printBoard() {
        System.out.println("Sudoku Board:");
        for (int row = 0; row < SIZE; row++) {
            if (row % BOX_SIZE == 0 && row != 0) {
                System.out.println("----------------------");
            }
            for (int col = 0; col < SIZE; col++) {
                if (col % BOX_SIZE == 0 && col != 0) {
                    System.out.print("| ");
                }
                System.out.print(board[row][col] + " ");
            }
            System.out.println();
        }
    }
}