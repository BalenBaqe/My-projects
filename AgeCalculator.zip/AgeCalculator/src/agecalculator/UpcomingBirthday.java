
package agecalculator;


public interface UpcomingBirthday {
    void nextBirthday();
}
