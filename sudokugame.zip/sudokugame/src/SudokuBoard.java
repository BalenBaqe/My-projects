public class SudokuBoard {
    private final int[][] easyBoard = {
            {9, 0, 7, 6, 8, 0, 2, 5, 4},
            {0, 0, 2, 0, 1, 0, 6, 8, 0},
            {0, 5, 8, 4, 0, 0, 9, 1, 0},
            {0, 0, 0, 0, 5, 6, 0, 9, 0},
            {0, 8, 1, 0, 4, 9, 0, 0, 0},
            {0, 0, 0, 8, 0, 0, 0, 0, 0},
            {0, 0, 9, 7, 6, 4, 0, 0, 0},
            {8, 6, 0, 0, 0, 2, 4, 0, 9},
            {3, 0, 4, 0, 9, 0, 1, 6, 0}
    };
    private boolean[][] easyGenerated;

    private final int[][] mediumBoard = {
            {0, 0, 0, 5, 0, 0, 0, 0, 0},
            {7, 0, 0, 0, 2, 9, 0, 8, 0},
            {4, 1, 5, 0, 0, 0, 0, 6, 0},
            {6, 0, 0, 9, 8, 0, 1, 0, 0},
            {0, 0, 0, 0, 5, 0, 9, 4, 0},
            {0, 0, 0, 6, 0, 3, 0, 0, 8},
            {1, 0, 7, 0, 0, 2, 6, 9, 0},
            {0, 8, 0, 0, 0, 0, 3, 5, 0},
            {0, 0, 0, 0, 4, 5, 0, 0, 2}
    };

    private boolean[][] mediumGenerated;

    private final int[][] hardBoard = {
            {0, 0, 0, 4, 2, 0, 0, 0, 0},
            {4, 0, 5, 3, 7, 0, 0, 9, 2},
            {0, 0, 0, 0, 0, 0, 0, 3, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {8, 3, 1, 2, 5, 0, 0, 0, 0},
            {0, 7, 0, 9, 0, 0, 0, 0, 1},
            {1, 0, 7, 0, 0, 0, 0, 0, 6},
            {0, 0, 0, 0, 0, 0, 0, 2, 8},
            {2, 0, 4, 1, 9, 6, 0, 0, 3}
    };

    private boolean[][] hardGenerated;

    private final int[][] expertBoard = {
            {0, 0, 0, 0, 0, 0, 5, 0, 0},
            {1, 0, 0, 4, 0, 6, 0, 0, 0},
            {0, 0, 0, 0, 5, 3, 0, 0, 0},
            {0, 2, 0, 0, 7, 0, 0, 0, 5},
            {7, 0, 0, 1, 0, 0, 0, 0, 0},
            {0, 0, 0, 9, 0, 0, 8, 0, 3},
            {0, 0, 9, 8, 0, 0, 0, 1, 0},
            {8, 3, 0, 0, 4, 9, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 3, 0, 0}
    };

    private boolean[][] expertGenerated;

    private final int[][] impossibleBoard = {
            {9, 0, 7, 6, 8, 0, 2, 5, 4},
            {0, 5, 2, 0, 1, 0, 6, 8, 0},
            {0, 5, 8, 4, 0, 0, 9, 1, 0},
            {9, 0, 0, 0, 5, 6, 0, 9, 0},
            {0, 8, 1, 0, 4, 9, 0, 0, 0},
            {0, 0, 0, 8, 0, 0, 0, 0, 0},
            {0, 0, 9, 7, 6, 4, 0, 0, 0},
            {8, 6, 0, 0, 5, 2, 4, 8, 9},
            {3, 8, 4, 0, 9, 0, 1, 6, 0}
    };
    private boolean[][] impossibleGenerated;

    SudokuBoard(){
        easyGenerated = checkForGenerated(easyBoard);
        mediumGenerated = checkForGenerated(mediumBoard);
        hardGenerated = checkForGenerated(hardBoard);
        expertGenerated = checkForGenerated(expertBoard);
        impossibleGenerated = checkForGenerated(impossibleBoard);
    }

    public boolean[][] checkForGenerated(int[][] bord) {
        boolean[][] generated = new boolean[9][9];
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (bord[row][col] != 0) {
                    generated[row][col] = true;
                }
            }
        }
        return generated;
    }

    public int[][] getEasyBoard() {
        return easyBoard;
    }

    public boolean[][] getEasyGenerated() {
        return easyGenerated;
    }

    public int[][] getMediumBoard() {
        return mediumBoard;
    }

    public boolean[][] getMediumGenerated() {
        return mediumGenerated;
    }

    public int[][] getHardBoard() {
        return hardBoard;
    }

    public boolean[][] getHardGenerated() {
        return hardGenerated;
    }

    public int[][] getExpertBoard() {
        return expertBoard;
    }

    public boolean[][] getExpertGenerated() {
        return expertGenerated;
    }

    public int[][] getImpossibleBoard() {
        return impossibleBoard;
    }

    public boolean[][] getImpossibleGenerated() {
        return impossibleGenerated;
    }
}
