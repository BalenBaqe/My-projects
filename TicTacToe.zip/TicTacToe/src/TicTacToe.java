import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class TicTacToe implements ActionListener {

    Random random = new Random();
    JFrame frame = new JFrame();
    JPanel tile_panel = new JPanel();
    JPanel button_panel = new JPanel();
    JLabel textField = new JLabel();
    JButton[] buttons = new JButton[9];
    private boolean player1_tern;

    public TicTacToe() {

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 700);
        frame.getContentPane().setBackground(new Color(50, 50, 50));
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        textField.setBackground(new Color(25, 25, 25));
        textField.setForeground(new Color(25, 255, 0));
        textField.setFont(new Font("Arrus BT", Font.BOLD, 75));
        textField.setHorizontalAlignment(JLabel.CENTER);
        textField.setText("Tic-Tac-Toe");

        tile_panel.setLayout(new BorderLayout());
        tile_panel.setBounds(0, 0, 800, 100);

        button_panel.setLayout(new GridLayout(3, 3));
        button_panel.setBackground(new Color(150, 150, 150));

        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new JButton();
            button_panel.add(buttons[i]);
            buttons[i].setFont(new Font("Arial", Font.BOLD, 150));
            buttons[i].setFocusable(false);
            buttons[i].addActionListener(this);
        }

        tile_panel.add(textField);
        frame.add(tile_panel, BorderLayout.NORTH);
        frame.add(button_panel);

        firstTurn();
    }

    private void firstTurn() {

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (random.nextInt(2) == 0) {
            player1_tern = true;
            textField.setText("X turn");
        } else {
            player1_tern = false;
            textField.setText("O turn");
        }
    }

    private void check() {
        // Define the winning combinations
        int[][] winningCombinations = {
                {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // Rows
                {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // Columns
                {0, 4, 8}, {2, 4, 6} // Diagonals
        };

        // Check X and O win conditions
        for (int[] combination : winningCombinations) {
            if (buttons[combination[0]].getText().equals("X")
                    && buttons[combination[1]].getText().equals("X")
                    && buttons[combination[2]].getText().equals("X")) {
                xWins(combination[0], combination[1], combination[2]);
                return;
            } else if (buttons[combination[0]].getText().equals("O")
                    && buttons[combination[1]].getText().equals("O")
                    && buttons[combination[2]].getText().equals("O")) {
                oWins(combination[0], combination[1], combination[2]);
                return;
            }
        }

        // Check for a draw
        boolean isDraw = true;
        for (JButton button : buttons) {
            if (button.getText().isEmpty()) {
                isDraw = false;
                break;
            }
        }

        if (isDraw && (textField.getText().equals("X tern") || textField.getText().equals("O tern"))) {
            draw();
        }
    }


    private void xWins(int a, int b, int c) {
        buttons[a].setBackground(Color.GREEN);
        buttons[b].setBackground(Color.GREEN);
        buttons[c].setBackground(Color.GREEN);

        for (int i = 0; i < 9; i++){
            buttons[i].setEnabled(false);
        }
        textField.setText("X wins");
    }

    private void oWins(int a, int b, int c) {
        buttons[a].setBackground(Color.GREEN);
        buttons[b].setBackground(Color.GREEN);
        buttons[c].setBackground(Color.GREEN);

        for (int i = 0; i < 9; i++){
            buttons[i].setEnabled(false);
        }
        textField.setText("O wins");
    }

    private void draw() {
        for (int i = 0; i < 9; i++){
            buttons[i].setEnabled(false);
        }
        textField.setText("Draw");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < 9; i++) {
            if (e.getSource()==buttons[i]){
                if (player1_tern){
                    if (buttons[i].getText().equals("")){
                        buttons[i].setForeground(Color.RED);
                        buttons[i].setText("X");
                        player1_tern = false;
                        textField.setText("O tern");
                        check();
                    }
                }
                else {
                    if (buttons[i].getText().equals("")) {
                        buttons[i].setForeground(Color.BLUE);
                        buttons[i].setText("O");
                        player1_tern = true;
                        textField.setText("X tern");
                        check();
                    }
                }
            }
        }
    }
}
