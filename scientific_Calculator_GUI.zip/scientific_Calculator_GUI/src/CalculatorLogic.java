public class CalculatorLogic {
    public double add(double a, double b) {
        return a + b;
    }

    public double subtract(double a, double b) {
        return a - b;
    }

    public double multiply(double a, double b) {
        return a * b;
    }

    public double divide(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return a / b;
    }

    public double sin(double a) {
        return Math.sin(Math.toRadians(a));
    }

    public double cos(double a) {
        return Math.cos(Math.toRadians(a));
    }

    public double tan(double a) {
        return Math.tan(Math.toRadians(a));
    }

    public double squareRoot(double a) {
        return Math.sqrt(a);
    }

    public double log(double a) {
        return Math.log10(a);
    }

    public double exp(double a) {
        return Math.exp(a);
    }

    public double square(double a) {
        return Math.pow(a, 2);
    }

    public double power(double a, double b) {
        return Math.pow(a, b);
    }

    public double modulus(double a, double b) {
        return a % b;
    }

    public double reciprocal(double a) {
        return 1 / a;
    }
}
