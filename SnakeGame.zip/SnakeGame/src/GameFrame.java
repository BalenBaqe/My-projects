import javax.swing.JFrame;
import javax.swing.ImageIcon;

public class GameFrame extends JFrame {

    GameFrame() {
    ImageIcon icon = new ImageIcon("C://Users//Dell//Downloads//snake.png");
        this.add(new GamePanel());
        this.setTitle("Two Player Snake");
        this.setIconImage(icon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

    }
}
