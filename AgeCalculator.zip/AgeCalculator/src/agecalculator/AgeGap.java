package agecalculator;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class AgeGap implements LifeTime, UpcomingBirthday {

    private String personOneName;
    private short personOneLivedDays;
    private short personOneLidedMonths;
    private short personOneLidedYears;
    private String personTwoName;
    private short personTwoLivedDays;
    private short personTwoLivedMonths;
    private short personTwoLivedYears;
    private BirthDate[] birthDates;

    public AgeGap() {
    }

    public AgeGap(String personOneName, String personTwoName, BirthDate[] birthDates) {
        this.setPersonOneName(personOneName);
        this.setPersonTwoName(personTwoName);
        this.setBirthDate(birthDates);
        personOneLivedDays = birthDates[0].calculateLivedDays();
        personOneLidedMonths = birthDates[0].calculateLivedMonth();
        personOneLidedYears = birthDates[0].calculateLivedYears();
        personTwoLivedDays = birthDates[1].calculateLivedDays();
        personTwoLivedMonths = birthDates[1].calculateLivedMonth();
        personTwoLivedYears = birthDates[1].calculateLivedYears();
        this.saveData();
    }

    public void setPersonOneName(String personOneName) {
        if (personOneName.length() > 10) {
            System.out.println("name can't be longer than 10 characters");
        } else {
            this.personOneName = personOneName;
        }
    }

    public void setPersonTwoName(String personTwoName) {
        if (personTwoName.length() > 10) {
            System.out.println("name can't be longer than 10 characters");
        } else {
            this.personTwoName = personTwoName;
        }
    }

    public void setBirthDate(BirthDate[] birthDates) {
        this.birthDates = birthDates;
    }

    public String getPersonOneName() {
        return personOneName;
    }

    public String getPersonTwoName() {
        return personTwoName;
    }

    public BirthDate[] getBirthDates() {
        return birthDates;
    }

    public short calculateDifferenceInDays() {
        short daysDifference;
        if (
                (personOneLidedYears > personTwoLivedYears)
                || ((personOneLidedYears == personTwoLivedYears)
                && (personOneLidedMonths >= personTwoLivedMonths))
         ) {
            if (personOneLivedDays >= personTwoLivedDays) {
                daysDifference = (short) (personOneLivedDays - personTwoLivedDays);
            } else {
                personOneLidedMonths--;
                daysDifference = (short) ((personOneLivedDays + 30) - personTwoLivedDays);
            }
        } else {
            if (personTwoLivedDays >= personOneLivedDays) {
                daysDifference = (short) (personTwoLivedDays - personOneLivedDays);
            } else {
                personTwoLivedMonths--;
                daysDifference = (short) ((personTwoLivedDays + 30) - personOneLivedDays);
            }
        }
        return daysDifference;
    }

    public short calculateDifferenceInMonths() {
        short monthsDifference;
        if (
                (personOneLidedYears > personTwoLivedYears)
                || ((personOneLidedYears == personTwoLivedYears)
                && (personOneLidedMonths >= personTwoLivedMonths))
         ) {
            if (personOneLidedMonths >= personTwoLivedMonths) {
                monthsDifference = (short) (personOneLidedMonths - personTwoLivedMonths);
            } else {
                personOneLidedYears--;
                monthsDifference = (short) ((personOneLidedMonths + 12) - personTwoLivedMonths);
            }
        } else {
            if (personTwoLivedMonths >= personOneLidedMonths) {
                monthsDifference = (short) (personTwoLivedMonths - personOneLidedMonths);
            } else {
                personTwoLivedYears--;
                monthsDifference = (short) ((personTwoLivedMonths + 12) - personOneLidedMonths);
            }
        }
        return monthsDifference;
    }

    public short calculateDifferenceInYears() {
        short yearsDifference;
        if (personOneLidedYears >= personTwoLivedYears) {
            yearsDifference = (short) (personOneLidedYears - personTwoLivedYears);
        } else {
            yearsDifference = (short) (personTwoLivedYears - personOneLidedYears);
        }
        return yearsDifference;
    }

    public String nextBirthdayCalculation(String personName, byte personIndex) {
        short nextBirthday;
        short nextBirthMonth;
        
        if (birthDates[personIndex].monthOfBirth >= birthDates[personIndex].currentMonth) {
            if (birthDates[personIndex].dayOfBirth >= birthDates[personIndex].currentDay) {
                 nextBirthMonth = (short) (birthDates[personIndex].monthOfBirth -birthDates[personIndex]. currentMonth);
            } else {
                 nextBirthMonth = (short) ((birthDates[personIndex].monthOfBirth -birthDates[personIndex]. currentMonth) - 1);
            }
        } else {
            if (birthDates[personIndex].dayOfBirth >= birthDates[personIndex].currentDay) {
                nextBirthMonth = (short) (12 - birthDates[personIndex].currentMonth + birthDates[personIndex].monthOfBirth);
            } else {
                nextBirthMonth = (short) ((12 - birthDates[personIndex].currentMonth) + (birthDates[personIndex].monthOfBirth - 1));
            }
        }
        
        if (birthDates[personIndex].dayOfBirth >= birthDates[personIndex].currentDay) {
            nextBirthday = (short) (birthDates[personIndex].dayOfBirth - birthDates[personIndex].currentDay);
        } else {
            nextBirthday = (short) ((30 - birthDates[personIndex].currentDay) + birthDates[personIndex].dayOfBirth);
        }
        return personName + "'S next birthday is in " + nextBirthMonth + " months and " + nextBirthday + "days";
    }

    private boolean checkWhoIsBigger() {
        return (personOneLidedYears > personTwoLivedYears)
                || ((personOneLidedYears == personTwoLivedYears)
                && (personOneLidedMonths > personTwoLivedMonths))
                || ((personOneLidedYears == personTwoLivedYears)
                && (personOneLidedMonths == personTwoLivedMonths)
                && (personOneLivedDays >= personTwoLivedDays));
    }

    public String personOneAge() {
        return personOneName + "'s age is " + personOneLivedDays + " Days " + personOneLidedMonths + " Month " + personOneLidedYears + " Years old";
    }

    public String personTwoAge() {
        return personTwoName + "'s age is " + personTwoLivedDays + " Days " + personTwoLivedMonths + " Month " + personTwoLivedYears + " Years old";
    }

    @Override
    public void nextBirthday() {
        System.out.println(nextBirthdayCalculation(personOneName, (byte) 0));
        System.out.println(nextBirthdayCalculation(personTwoName, (byte) 1));
        System.out.println();
    }

    @Override
    public void lifeDuration() {
        System.out.println(personOneAge());
        System.out.println(personTwoAge() + "\n");
    }

    public String calculateAgeDifference() {
        if ((personOneLidedYears == personTwoLivedYears) && (personOneLidedMonths == personTwoLivedMonths) && (personOneLivedDays == personTwoLivedDays)) {
            return personOneName + " and " + personTwoName + " have the same age";
        } else if (checkWhoIsBigger()) {
            return personOneName + " is " + calculateDifferenceInDays() + " Days "
                    + calculateDifferenceInMonths() + " Months "
                    + calculateDifferenceInYears() + " Years bigger than " + personTwoName;
        } else {
            return personTwoName + " is " + calculateDifferenceInDays() + " Days "
                    + calculateDifferenceInMonths() + " Months "
                    + calculateDifferenceInYears() + " Years bigger than " + personOneName;
        }
    }

    public void saveData() {
        try {
            FileWriter fileWriter = new FileWriter("data.dat", true);
            PrintWriter writer = new PrintWriter(fileWriter);
            writer.println("current date is : " + birthDates[0].currentDay + "/" + birthDates[0].currentMonth + "/" + birthDates[0].currentYear);
            writer.println(personOneName + " birth day is in: " + birthDates[0].dayOfBirth + "/" + birthDates[0].monthOfBirth + "/" + birthDates[0].yearOfBirth);
            writer.println(personTwoName + " birth day is in: " + birthDates[1].dayOfBirth + "/" + birthDates[1].monthOfBirth + "/" + birthDates[1].yearOfBirth);
            writer.println(nextBirthdayCalculation(personOneName, (byte) 0));
            writer.println(nextBirthdayCalculation(personTwoName, (byte) 1));
            writer.println(personOneAge());
            writer.println(personTwoAge());
            writer.println(calculateAgeDifference());
            writer.println("***************************************************************************");
            writer.close();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        personOneLidedMonths = birthDates[0].calculateLivedMonth();
        personOneLidedYears = birthDates[0].calculateLivedYears();
        personTwoLivedMonths = birthDates[1].calculateLivedMonth();
        personTwoLivedYears = birthDates[1].calculateLivedYears();
    }

    @Override
    public String toString() {
        return calculateAgeDifference();
    }
}
