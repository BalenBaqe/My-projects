import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.StyleConstants;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class TextEditorApp extends JFrame {
    private JTextPane textArea;
    private JFileChooser fileChooser;
    private File currentFile;
    private UndoManager undoManager;

    public TextEditorApp() {
        setTitle("Text Editor");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        createMenuBar();
        createTextArea();

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                exitApp();
            }
        });
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // File menu
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);

        JMenuItem newMenuItem = new JMenuItem("New", KeyEvent.VK_N);
        newMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
        newMenuItem.addActionListener(e -> newFile());

        JMenuItem openMenuItem = new JMenuItem("Open", KeyEvent.VK_O);
        openMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
        openMenuItem.addActionListener(e -> openFile());

        JMenuItem saveMenuItem = new JMenuItem("Save", KeyEvent.VK_S);
        saveMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
        saveMenuItem.addActionListener(e -> saveFile());

        JMenuItem saveAsMenuItem = new JMenuItem("Save As");
        saveAsMenuItem.addActionListener(e -> saveFileAs());

        JMenuItem exitMenuItem = new JMenuItem("Exit", KeyEvent.VK_X);
        exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.ALT_MASK));
        exitMenuItem.addActionListener(e -> exitApp());

        fileMenu.add(newMenuItem);
        fileMenu.add(openMenuItem);
        fileMenu.add(saveMenuItem);
        fileMenu.add(saveAsMenuItem);
        fileMenu.addSeparator();
        fileMenu.add(exitMenuItem);

        // Edit menu
        JMenu editMenu = new JMenu("Edit");
        editMenu.setMnemonic(KeyEvent.VK_E);

        JMenuItem cutMenuItem = new JMenuItem(new DefaultEditorKit.CutAction());
        cutMenuItem.setText("Cut");
        cutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));

        JMenuItem copyMenuItem = new JMenuItem(new DefaultEditorKit.CopyAction());
        copyMenuItem.setText("Copy");
        copyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK));

        JMenuItem pasteMenuItem = new JMenuItem(new DefaultEditorKit.PasteAction());
        pasteMenuItem.setText("Paste");
        pasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));

        JMenuItem undoMenuItem = new JMenuItem("Undo");
        undoMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_MASK));
        undoMenuItem.addActionListener(e -> undo());

        JMenuItem redoMenuItem = new JMenuItem("Redo");
        redoMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_MASK));
        redoMenuItem.addActionListener(e -> redo());

        editMenu.add(cutMenuItem);
        editMenu.add(copyMenuItem);
        editMenu.add(pasteMenuItem);
        editMenu.addSeparator();
        editMenu.add(undoMenuItem);
        editMenu.add(redoMenuItem);

        // Format menu
        JMenu formatMenu = new JMenu("Format");
        formatMenu.setMnemonic(KeyEvent.VK_O);

        JMenuItem fontMenuItem = new JMenuItem("Font");
        fontMenuItem.addActionListener(e -> chooseFont());

        JMenuItem colorMenuItem = new JMenuItem("Color");
        colorMenuItem.addActionListener(e -> chooseColor());

        formatMenu.add(fontMenuItem);
        formatMenu.add(colorMenuItem);

        // Add menus to menu bar
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(formatMenu);

        // Set the menu bar
        setJMenuBar(menuBar);
    }

    private void createTextArea() {
        textArea = new JTextPane();
        textArea.setFont(new Font("Courier New", Font.PLAIN, 16));
        textArea.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                updateTitle();
            }

            public void removeUpdate(DocumentEvent e) {
                updateTitle();
            }

            public void changedUpdate(DocumentEvent e) {
                updateTitle();
            }
        });

        undoManager = new UndoManager();

        textArea.getDocument().addUndoableEditListener(undoManager);

        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane);
    }

    private void updateTitle() {
        if (currentFile != null) {
            setTitle("Text Editor - " + currentFile.getName() + "*");
        } else {
            setTitle("Text Editor");
        }
    }

    private void newFile() {
        if (confirmSaveChanges()) {
            textArea.setText("");
            currentFile = null;
            updateTitle();
        }
    }

    private void openFile() {
        if (confirmSaveChanges()) {
            if (fileChooser == null) {
                fileChooser = new JFileChooser();
                fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));
            }

            int returnVal = fileChooser.showOpenDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try {
                    FileReader fileReader = new FileReader(file);
                    textArea.read(fileReader, null);
                    fileReader.close();
                    currentFile = file;
                    updateTitle();
                } catch (IOException e) {
                    showMessage("Failed to open file.");
                }
            }
        }
    }

    private void saveFile() {
        if (currentFile != null) {
            saveToFile(currentFile);
        } else {
            saveFileAs();
        }
    }

    private void saveFileAs() {
        if (fileChooser == null) {
            fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new FileNameExtensionFilter("Text Files", "txt"));
        }

        int returnVal = fileChooser.showSaveDialog(this);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            saveToFile(file);
            currentFile = file;
            updateTitle();
        }
    }

    private void saveToFile(File file) {
        try {
            FileWriter fileWriter = new FileWriter(file);
            textArea.write(fileWriter);
            fileWriter.close();
        } catch (IOException e) {
            showMessage("Failed to save file.");
        }
    }

    private boolean confirmSaveChanges() {
        if (currentFile != null && textArea.getText().equals(readFile(currentFile))) {
            return true;
        }

        int option = JOptionPane.showConfirmDialog(this, "Do you want to save the changes?");
        if (option == JOptionPane.YES_OPTION) {
            saveFile();
            return true;
        } else return option == JOptionPane.NO_OPTION;
    }

    private void exitApp() {
        if (confirmSaveChanges()) {
            System.exit(0);
        }
    }

    private String readFile(File file) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
        } catch (IOException e) {
            showMessage("Failed to read file.");
        }
        return sb.toString();
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void undo() {
        if (undoManager.canUndo()) {
            try {
                undoManager.undo();
            } catch (CannotUndoException e) {
                showMessage("Undo failed.");
            }
        }
    }

    private void redo() {
        if (undoManager.canRedo()) {
            try {
                undoManager.redo();
            } catch (CannotRedoException e) {
                showMessage("Redo failed.");
            }
        }
    }

    private void chooseFont() {
        Font selectedFont = changeFont();
        if (selectedFont != null) {
            textArea.setFont(selectedFont);
        }
    }

    private Font changeFont() {
        FontChooserDialog fontChooser = new FontChooserDialog(this, textArea.getFont());
        fontChooser.setVisible(true);
        Font selectedFont = fontChooser.getSelectedFont();
        if (selectedFont != null) {
            textArea.setFont(selectedFont);
        }
        return selectedFont;
    }

    private void chooseColor() {
        Color selectedColor = JColorChooser.showDialog(this, "Choose Color", textArea.getForeground());
        if (selectedColor != null) {
            StyleConstants.setForeground(textArea.getStyledDocument().getStyle("default"), selectedColor);
        }
    }

}
