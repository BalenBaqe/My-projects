
package agecalculator;


public interface LifeTime {
    void lifeDuration();
}
