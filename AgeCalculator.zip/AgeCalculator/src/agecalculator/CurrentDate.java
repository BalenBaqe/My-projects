package agecalculator;

import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class CurrentDate {

    private final SimpleDateFormat SIMPLE_YEAR = new SimpleDateFormat("yyyy");
    private final SimpleDateFormat SIMPLE_MONTH = new SimpleDateFormat("MM");
    private final SimpleDateFormat SIMPLE_DAY = new SimpleDateFormat("dd");
    private final Date DATE = new Date();
    private final String SYSTEM_YEAR = SIMPLE_YEAR.format(DATE);
    private final String SYSTEM_MONTH = SIMPLE_MONTH.format(DATE);
    private final String SYSTEM_DAY = SIMPLE_DAY.format(DATE);
    protected short currentYear = Short.parseShort(SYSTEM_YEAR);
    protected short currentMonth = Short.parseShort(SYSTEM_MONTH);
    protected short currentDay = Short.parseShort(SYSTEM_DAY);

    public short getCurrentYear() {
        return currentYear;
    }

    public short getCurrentMonth() {
        return currentMonth;
    }

    public short getCurrentDay() {
        return currentDay;
    }
}
