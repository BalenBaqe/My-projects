package main;

import console.ConsoleApp;

import GUI.AppFrame;

public class Main {
    public static void main(String[] args) {
       new AppFrame().setVisible(true);
        
        //comment the line abave and GUI import then comment out the line under and the import console to run this program using concole
        
        //new ConsoleApp();
    }
}