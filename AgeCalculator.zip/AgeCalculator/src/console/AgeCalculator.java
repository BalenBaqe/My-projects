package console;

import agecalculator.BirthDate;
import java.util.Scanner;

public class AgeCalculator {
    public AgeCalculator() {
        Scanner in = new Scanner(System.in);
        short day = 0;
        short month = 0;
        short year = 0;
        try {
            System.out.print("Enter Your Day Of Berth: ");
            day = in.nextShort();
            System.out.print("Enter Your Mouth Of Berth: ");
            month = in.nextShort();
            System.out.print("Enter Your Year Of Berth: ");
            year = in.nextShort();
        } catch (Exception e) {
            System.out.println("Enter only digits for day, month and year");
            System.exit(1);
        }

        System.out.println();

        BirthDate birthDate = new BirthDate(day, month, year);
        birthDate.lifeDuration();
        birthDate.nextBirthday();
        birthDate.calculateAge();
    }
}

