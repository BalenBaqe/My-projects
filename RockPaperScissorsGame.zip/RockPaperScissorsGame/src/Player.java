public enum Player {
    USER, MACHINE,TIE;
}