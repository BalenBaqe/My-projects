package console;

import java.util.Scanner;

public class ConsoleApp {

    public ConsoleApp() {
                Scanner in = new Scanner(System.in);
        loop:
        while (true) {
            System.out.println("Enter 1 for Age Calculation, 2 for Age Difference between Two persons, 0 to exit: ");
            String choice = in.next();

            switch (choice) {
                case "1":
                    new AgeCalculator();
                    break loop;
                case "2":
                    new AgeDifference();
                    break loop;
                case "0":
                    break loop;
                default:
                    System.out.println("Enter only 1, 2 or 0");
                    break;
            }
        }
    }
    
}
