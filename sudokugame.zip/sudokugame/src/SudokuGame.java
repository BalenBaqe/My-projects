import java.util.Arrays;
import java.util.Scanner;

public class SudokuGame {

    // Create a new SudokuBoard instance
    SudokuBoard newBoard = new SudokuBoard();

    // Declare instance variables
    private int[][] initialBoard;
    private int[][] board;
    private boolean[][] generated;
    private int hintUsage = 0;
    private SudokuSolver solver;

    // Method to play the Sudoku game
    public void playGame() {
        Scanner in = new Scanner(System.in);
        int row;
        int col;
        int num;

        // Prompt the user to enter the preferred difficulty level
        System.out.print("Enter your preferred difficulty (easy, medium, hard, expert, impossible): ");
        String difficulty = in.next().toLowerCase();

        // Loop to handle difficulty selection and initialize the game board accordingly
        difficultyChosen:
        while (true) {
            switch (difficulty) {
                case "easy":
                    initialBoard = newBoard.getEasyBoard();
                    board = deepCopy(initialBoard);
                    generated = newBoard.getEasyGenerated();
                    break difficultyChosen;
                case "medium":
                    initialBoard = newBoard.getMediumBoard();
                    board = deepCopy(initialBoard);
                    generated = newBoard.getMediumGenerated();
                    break difficultyChosen;
                case "hard":
                    initialBoard = newBoard.getHardBoard();
                    board = deepCopy(initialBoard);
                    generated = newBoard.getHardGenerated();
                    break difficultyChosen;
                case "expert":
                    initialBoard = newBoard.getExpertBoard();
                    board = deepCopy(initialBoard);
                    generated = newBoard.getExpertGenerated();
                    break difficultyChosen;
                case "impossible":
                    initialBoard = newBoard.getImpossibleBoard();
                    board = deepCopy(initialBoard);
                    generated = newBoard.getImpossibleGenerated();
                    break difficultyChosen;
                default:
                    System.out.println("Invalid difficulty level. Try again.");
                    difficulty = in.next().toLowerCase();
                    break;
            }
        }
        //Send the bord to the AI
        solver = new SudokuSolver(initialBoard);

        // Print the initial game board
        printBoard();
        in.nextLine();

        // Main game loop to accept user inputs and perform game actions
        while (!isBoardComplete()) {
            System.out.print("Enter row, column, and number (separated by spaces) or 'hint' or 'solve': ");
            String input = in.nextLine().trim();

            if (input.equalsIgnoreCase("hint")) {
                if(isBoardSolvable()){
                    // Process the hint action
                    System.out.print("Enter row and column (separated by spaces): ");
                    row = in.nextInt();
                    col = in.nextInt();
                    board[row][col] = giveHint(row, col);
                    printBoard();
                    System.out.println("Hint given, Hint used solar: " + hintUsage);
                    System.out.println("row: " + row + " col: " + col + " changed to " + board[row][col]);
                    in.nextLine();
                } else {
                    System.out.println("Board have no solution it is impossible to solve");
                }

            } else if (input.equalsIgnoreCase("solve")) {
                // Process the solve action
                solveBoard();
                break;
            } else {
                String[] inputParts = input.split(" ");

                if (inputParts.length == 3) {
                    // Process the user's move
                    row = Integer.parseInt(inputParts[0]);
                    col = Integer.parseInt(inputParts[1]);
                    num = Integer.parseInt(inputParts[2]);

                    if (isValidMove(row, col, num)) {
                        board[row][col] = num;
                        printBoard();
                    } else {
                        System.out.println("Invalid number! Try again.");
                    }
                } else {
                    System.out.println("Invalid input! Try again.");
                }
            }
        }
        // Check if the board is solved and print the appropriate message
        if (isBordSolved() && isBoardSolvable()) {
            System.out.println("Congratulations, you won! 🥳 " + hintUsage + " hint used");
        } else {
            System.out.println("You lost 🥲 Better luck next time 😁");
        }
    }

    // Method to check if the game board is complete
    public boolean isBoardComplete() {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (board[row][col] == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    // Method to check if the board is solved by comparing it to the goal board
    public boolean isBordSolved() {
        int[][] goalBoard = solver.getHint();
        return Arrays.deepEquals(board, goalBoard);
    }

    //Checks if the current Sudoku board is solvable
    public boolean isBoardSolvable(){
        return solver.dfs();
    }

    // Method to check if a move is valid
    public boolean isValidMove(int row, int col, int num) {
        // Check if the move is on a generated (initial) cell
        if (generated[row][col]) {
            return false;
        }
        // Check if the cell is already filled
        if (board[row][col] != 0) {
            return true;
        }
        // Check for conflicts in the same row and column
        for (int i = 0; i < 9; i++) {
            if (board[row][i] == num || board[i][col] == num) {
                return false;
            }
        }
        // Check for conflicts in the 3x3 box
        int boxRow = row / 3 * 3;
        int boxCol = col / 3 * 3;
        for (int i = boxRow; i < boxRow + 3; i++) {
            for (int j = boxCol; j < boxCol + 3; j++) {
                if (board[i][j] == num) {
                    return false;
                }
            }
        }
        return true;
    }

    // Method to print the game board
    public void printBoard() {
        System.out.println("Sudoku Board:");
        for (int row = 0; row < 9; row++) {
            if (row % 3 == 0 && row != 0) {
                System.out.println("----------------------");
            }
            for (int col = 0; col < 9; col++) {
                if (col % 3 == 0 && col != 0) {
                    System.out.print("| ");
                }
                System.out.print(board[row][col] + " ");
            }
            System.out.println();
        }
    }

    // Method to create a deep copy of a 2D array
    private int[][] deepCopy(int[][] array) {
        int[][] copy = new int[array.length][];
        for (int i = 0; i < array.length; i++) {
            copy[i] = Arrays.copyOf(array[i], array[i].length);
        }
        return copy;
    }

    // Method to provide a hint for a specific cell
    public int giveHint(int row, int col) {
        hintUsage++;
        int[][] goalBoard = solver.getHint();
        generated[row][col] = true;
        return goalBoard[row][col];
    }

    // Method to solve the game board
    public void solveBoard() {
        solver.solve();
        board = solver.getHint();
    }

}

