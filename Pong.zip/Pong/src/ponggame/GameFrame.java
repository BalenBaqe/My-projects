package ponggame;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import java.awt.Color;

public class GameFrame extends JFrame {
    public GameFrame(){
        ImageIcon icon = new ImageIcon("C://Users//Dell//Downloads//ping-pong.png");
        this.add(new GamePanel());
        this.setTitle("Pong Game");
        this.setResizable(false);
        this.setIconImage(icon.getImage());
        this.setBackground(Color.black);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
}