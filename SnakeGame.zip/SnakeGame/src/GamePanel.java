import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener {

    private static final int SCREEN_WIDTH = 1200;
    private static final int SCREEN_HEIGHT = 650;
    private static final int UNIT_SIZE = 35;
    private static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / (UNIT_SIZE * UNIT_SIZE);
    private static final int DELAY = 170;
    private final int[] playerOneX = new int[GAME_UNITS];
    private final int[] playerOneY = new int[GAME_UNITS];
    private final int[] playerTwoX = new int[GAME_UNITS];
    private final int[] playerTwoY = new int[GAME_UNITS];
    private int playerOneBodyParts = 4;
    private int playerTwoBodyParts = 4;
    private int applesConsumed;
    private String highScore = "";
    private int appleOneX, appleTwoX;
    private int appleOneY, appleTwoY;
    private char playerOneDirection = 'R';
    private char playerTwoDirection = 'D';
    private boolean running = false;
    Timer timer;
    Random random;

    GamePanel() {
        random = new Random();
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(new Color(50, 170, 70));
        this.setFocusable(true);
        this.addKeyListener(new MyKeyAdapter());
        startGame();
    }

    public void startGame() {
        newApple();
        newAppleTwo();
        running = true;
        timer = new Timer(DELAY, this);
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {

        if (running) {
            // The 3 following lines will draw 2 apples
            g.setColor(Color.RED);
            g.fillOval(appleOneX, appleOneY, UNIT_SIZE, UNIT_SIZE);
            g.fillOval(appleTwoX, appleTwoY, UNIT_SIZE, UNIT_SIZE);
            // The following lines will draw Player one
            for (int i = 0; i < playerOneBodyParts; i++) {
                if (i == 0) {
                    g.setColor(Color.cyan);
                    g.fillRect(playerOneX[i], playerOneY[i], UNIT_SIZE, UNIT_SIZE);
                } else {
                    g.setColor(new Color(45, 140, 200));
                    //g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
                    g.fillRect(playerOneX[i], playerOneY[i], UNIT_SIZE, UNIT_SIZE);
                }
            }
            // The following lines will draw Player two
            for (int i = 0; i < playerTwoBodyParts; i++) {
                if (i == 0) {
                    g.setColor(Color.pink);
                    g.fillRect(playerTwoX[i], playerTwoY[i], UNIT_SIZE, UNIT_SIZE);
                } else {
                    g.setColor(new Color(190, 4, 90));
                    //g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
                    g.fillRect(playerTwoX[i], playerTwoY[i], UNIT_SIZE, UNIT_SIZE);
                }
            }
            g.setColor(new Color(0x59006064, true));
            g.setFont(new Font("Arial", Font.BOLD, 40));
            FontMetrics metrics = getFontMetrics(g.getFont());
            g.drawString("Score: " + applesConsumed, (SCREEN_WIDTH - metrics.stringWidth("Score: " + applesConsumed)) / 2, g.getFont().getSize());
        } else {
            gameOver(g);
        }

    }

    public void newApple() {
        appleOneX = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
        appleOneY = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void newAppleTwo() {
        appleTwoX = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
        appleTwoY = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void move() {
        for (int i = playerOneBodyParts; i > 0; i--) {
            playerOneX[i] = playerOneX[i - 1];
            playerOneY[i] = playerOneY[i - 1];
        }

        for (int i = playerTwoBodyParts; i > 0; i--) {
            playerTwoX[i] = playerTwoX[i - 1];
            playerTwoY[i] = playerTwoY[i - 1];
        }

        switch (playerOneDirection) {
            case 'U':
                playerOneY[0] = playerOneY[0] - UNIT_SIZE;
                break;
            case 'D':
                playerOneY[0] = playerOneY[0] + UNIT_SIZE;
                break;
            case 'L':
                playerOneX[0] = playerOneX[0] - UNIT_SIZE;
                break;
            case 'R':
                playerOneX[0] = playerOneX[0] + UNIT_SIZE;
                break;
        }

        switch (playerTwoDirection) {
            case 'U':
                playerTwoY[0] = playerTwoY[0] - UNIT_SIZE;
                break;
            case 'D':
                playerTwoY[0] = playerTwoY[0] + UNIT_SIZE;
                break;
            case 'L':
                playerTwoX[0] = playerTwoX[0] - UNIT_SIZE;
                break;
            case 'R':
                playerTwoX[0] = playerTwoX[0] + UNIT_SIZE;
                break;
        }

    }

    public void checkApple() {
        if ((playerOneX[0] == appleOneX) && (playerOneY[0] == appleOneY)) {
            playerOneBodyParts++;
            applesConsumed++;
            newApple();
        }

        if ((playerTwoX[0] == appleOneX) && (playerTwoY[0] == appleOneY)) {
            playerTwoBodyParts++;
            applesConsumed++;
            newApple();
        }
    }

    public void checkAppleTwo() {
        if ((playerOneX[0] == appleTwoX) && (playerOneY[0] == appleTwoY)) {
            playerOneBodyParts++;
            applesConsumed++;
            newAppleTwo();
        }

        if ((playerTwoX[0] == appleTwoX) && (playerTwoY[0] == appleTwoY)) {
            playerTwoBodyParts++;
            applesConsumed++;
            newAppleTwo();
        }
    }

    public void checkCollisions() {
        //checks if head collides with body
        for (int i = playerOneBodyParts; i > 0; i--) {
            if ((playerOneX[0] == playerOneX[i]) && (playerOneY[0] == playerOneY[i])) {
                running = false;
                break;
            }
        }
        //checks if head collides with body
        for (int i = playerTwoBodyParts; i > 0; i--) {
            if ((playerTwoX[0] == playerTwoX[i]) && (playerTwoY[0] == playerTwoY[i])) {
                running = false;
                break;
            }
        }
        //checks if players collides with each other
        for (int i = playerTwoBodyParts; i > 0; i--) {
            if ((playerTwoX[0] == playerOneX[0]) && (playerTwoY[0] == playerOneY[0])) {
                running = false;
                break;
            }
        }
        //check if head touches left border
        if (playerOneX[0] < 0 || playerTwoX[0] < 0) {
            running = false;
        }
        //check if head touches right border
        if (playerOneX[0] > SCREEN_WIDTH || playerTwoX[0] > SCREEN_WIDTH) {
            running = false;
        }
        //check if head touches top border
        if (playerOneY[0] < 0 || playerTwoY[0] < 0) {
            running = false;
        }
        //check if head touches bottom border
        if (playerOneY[0] > SCREEN_HEIGHT || playerTwoY[0] > SCREEN_HEIGHT) {
            running = false;
        }

        if (!running) {
            timer.stop();
        }
    }

    public void checkScore() {
        if (highScore.equals(""))
            return;
        //user has to set a new record
        if (applesConsumed > Integer.parseInt((highScore.split(":")[1]))) {
            String name = JOptionPane.showInputDialog("You two set a new high score what is your names?");
            highScore = name + ":" + applesConsumed;

            File scoreFile = new File("highscore.det");
            if (!scoreFile.exists()) {
                try {
                    scoreFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            FileWriter writeFile;
            BufferedWriter writer = null;
            try {
                writeFile = new FileWriter(scoreFile);
                writer = new BufferedWriter(writeFile);
                writer.write(this.highScore);
            } catch (Exception e){

            }
            finally {
                try {
                    if(writer != null)
                        writer.close();
                } catch (Exception e) {}
            }
        }
    }

    public String getHighScore() {
        FileReader readFile;
        BufferedReader reader = null;
        try {
            readFile = new FileReader("highscore.det");
            reader = new BufferedReader(readFile);
            return reader.readLine();
        } catch (Exception e) {
            return "Nobody:0";
        } finally {
            try {
                if (reader != null)
                    reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void gameOver(Graphics g) {
        if (highScore.equals("")) {
            highScore = this.getHighScore();
        }
        checkScore();
        // Display The Score
        g.setColor(new Color(0xE9F42336, true));
        g.setFont(new Font("Arrus BT", Font.BOLD, 40));
        FontMetrics metrics1 = getFontMetrics(g.getFont());
        g.drawString("Score: " + applesConsumed, (SCREEN_WIDTH - metrics1.stringWidth("Score: " + applesConsumed)) / 2, 400 - g.getFont().getSize());
        g.drawString("Highest Score: " + highScore, (1050 - metrics1.stringWidth("Score: " + highScore)) / 2, 450 - g.getFont().getSize());
        // Game over text
        g.setColor(new Color(0xE0F42136, true));
        g.setFont(new Font("Arrus BT", Font.BOLD, 75));
        FontMetrics metrics2 = getFontMetrics(g.getFont());
        g.drawString("Game Over", (SCREEN_WIDTH - metrics2.stringWidth("Game Over")) / 2, SCREEN_HEIGHT / 2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (running) {
            move();
            checkApple();
            checkAppleTwo();
            checkCollisions();
        }
        repaint();
    }

    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:
                    if (playerOneDirection != 'R') {
                        playerOneDirection = 'L';
                    }
                    break;
                case KeyEvent.VK_RIGHT:
                    if (playerOneDirection != 'L') {
                        playerOneDirection = 'R';
                    }
                    break;
                case KeyEvent.VK_UP:
                    if (playerOneDirection != 'D') {
                        playerOneDirection = 'U';
                    }
                    break;
                case KeyEvent.VK_DOWN:
                    if (playerOneDirection != 'U') {
                        playerOneDirection = 'D';
                    }
                    break;
            }
            switch (e.getKeyCode()) {
                case KeyEvent.VK_A:
                    if (playerTwoDirection != 'R') {
                        playerTwoDirection = 'L';
                    }
                    break;
                case KeyEvent.VK_D:
                    if (playerTwoDirection != 'L') {
                        playerTwoDirection = 'R';
                    }
                    break;
                case KeyEvent.VK_W:
                    if (playerTwoDirection != 'D') {
                        playerTwoDirection = 'U';
                    }
                    break;
                case KeyEvent.VK_S:
                    if (playerTwoDirection != 'U') {
                        playerTwoDirection = 'D';
                    }
                    break;
            }
        }
    }
}
