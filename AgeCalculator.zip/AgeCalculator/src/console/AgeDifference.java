package console;

import agecalculator.AgeGap;
import agecalculator.BirthDate;
import java.util.Scanner;

public class AgeDifference {
    public AgeDifference() {
        Scanner in = new Scanner(System.in);
        String personOneName = "";
        short personOneBirthDay = 0;
        short personOneBirtMonth = 0;
        short personOneBirtYear = 0;
        String personTwoName = "";
        short personTwoBirthDay = 0;
        short personTwoBirtMonth = 0;
        short personTwoBirtYear = 0;
        try {
            System.out.print("Enter a Name: ");
            personOneName = in.next();
            System.out.print("Enter Your Day Of Berth: ");
            personOneBirthDay = in.nextShort();
            System.out.print("Enter Your Mouth Of Berth: ");
            personOneBirtMonth = in.nextShort();
            System.out.print("Enter Your Year Of Berth: ");
            personOneBirtYear = in.nextShort();

            System.out.print("Enter a Name: ");
            personTwoName = in.next();
            System.out.print("Enter Your Day Of Berth: ");
            personTwoBirthDay = in.nextShort();
            System.out.print("Enter Your Mouth Of Berth: ");
            personTwoBirtMonth = in.nextShort();
            System.out.print("Enter Your Year Of Berth: ");
            personTwoBirtYear = in.nextShort();
        } catch (Exception e) {
            System.out.println("Enter only digits for day, month and year");
            System.exit(1);
        }

        System.out.println();

        BirthDate[] birthdateList = {
                new BirthDate(personOneBirthDay, personOneBirtMonth, personOneBirtYear),
                new BirthDate(personTwoBirthDay, personTwoBirtMonth, personTwoBirtYear)
        };
        AgeGap ageGap = new AgeGap(personOneName, personTwoName, birthdateList);
        ageGap.lifeDuration();
        ageGap.nextBirthday();
        System.out.println(ageGap);
    }

}
