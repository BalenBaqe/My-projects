import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorGUI {
    private JFrame frame;
    private JTextField inputField;
    private JButton[] numberButtons;
    private JButton[] operatorButtons;
    private JButton equalsButton;
    private JButton clearButton;

    private double firstNumber;
    private String operator;
    private CalculatorLogic calculatorLogic;

    public void createAndShowGUI() {
        frame = new JFrame("Scientific Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 550);
        frame.setLayout(new BorderLayout());

        calculatorLogic = new CalculatorLogic();

        createComponents();
        addComponents();

        frame.setVisible(true);
    }

    private void createComponents() {
        inputField = new JTextField();
        inputField.setEditable(false);
        inputField.setHorizontalAlignment(JTextField.RIGHT);
        inputField.setFont(new Font("Arial", Font.BOLD, 26));

        numberButtons = new JButton[10];
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].setFont(new Font("Arial", Font.BOLD, 24));
        }

        operatorButtons = new JButton[30];
        operatorButtons[0] = new JButton("+");
        operatorButtons[1] = new JButton("-");
        operatorButtons[2] = new JButton("*");
        operatorButtons[3] = new JButton("/");
        operatorButtons[4] = new JButton("sin");
        operatorButtons[5] = new JButton("cos");
        operatorButtons[6] = new JButton("tan");
        operatorButtons[7] = new JButton("√");
        operatorButtons[8] = new JButton("log");
        operatorButtons[9] = new JButton("exp");
        operatorButtons[10] = new JButton("x^2");
        operatorButtons[11] = new JButton("x^y");
        operatorButtons[12] = new JButton("mod");
        operatorButtons[13] = new JButton("π");
        operatorButtons[14] = new JButton("e");
        operatorButtons[15] = new JButton("1/x");
        operatorButtons[16] = new JButton("CE");
        operatorButtons[17] = new JButton("C");
        operatorButtons[18] = new JButton("!");
        operatorButtons[19] = new JButton("log2");
        operatorButtons[20] = new JButton("logn");
        operatorButtons[21] = new JButton("ln");
        operatorButtons[22] = new JButton("x!");
        operatorButtons[23] = new JButton("(");
        operatorButtons[24] = new JButton(")");
        operatorButtons[25] = new JButton("10^x");
        operatorButtons[26] = new JButton("e^x");
        operatorButtons[27] = new JButton("abs");
        operatorButtons[28] = new JButton("floor");
        operatorButtons[29] = new JButton("ceil");

        equalsButton = new JButton("=");
        clearButton = new JButton("AC");

        addActionListeners();
    }

    private void addComponents() {
        JPanel numberPanel = new JPanel();
        numberPanel.setLayout(new GridLayout(4, 3, 5, 5));
        for (int i = 1; i <= 9; i++) {
            numberPanel.add(numberButtons[i]);
        }

        numberPanel.add(numberButtons[0]);
        numberPanel.add(operatorButtons[16]); // CE
        numberPanel.add(operatorButtons[17]); // C

        JPanel functionalPanel = new JPanel();
        functionalPanel.setLayout(new GridLayout(6, 4, 5, 5));
        functionalPanel.add(operatorButtons[0]); // *
        functionalPanel.add(operatorButtons[1]); // -
        functionalPanel.add(operatorButtons[2]); // *
        functionalPanel.add(operatorButtons[3]); // /
        functionalPanel.add(operatorButtons[23]); // (
        functionalPanel.add(operatorButtons[24]); // )
        functionalPanel.add(operatorButtons[25]); // 10^x
        functionalPanel.add(operatorButtons[26]); // e^x
        functionalPanel.add(operatorButtons[18]); // !
        functionalPanel.add(operatorButtons[19]); // log2
        functionalPanel.add(operatorButtons[20]); // logn
        functionalPanel.add(operatorButtons[21]); // ln
        functionalPanel.add(operatorButtons[8]); // log
        functionalPanel.add(operatorButtons[9]); // exp
        functionalPanel.add(operatorButtons[13]); // (
        functionalPanel.add(operatorButtons[22]); // x!
        functionalPanel.add(operatorButtons[7]); // √
        functionalPanel.add(operatorButtons[4]); // sin
        functionalPanel.add(operatorButtons[5]); // cos
        functionalPanel.add(operatorButtons[6]); // tan
        functionalPanel.add(operatorButtons[27]); // abs
        functionalPanel.add(operatorButtons[28]); // floor
        functionalPanel.add(operatorButtons[29]); // ceil
        functionalPanel.add(operatorButtons[12]); // mod
        functionalPanel.add(operatorButtons[11]); // x^y
        functionalPanel.add(operatorButtons[15]); // 1/x

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BorderLayout(5, 5));
        buttonPanel.add(numberPanel, BorderLayout.CENTER);
        buttonPanel.add(functionalPanel, BorderLayout.EAST);

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout(5, 5));
        topPanel.add(inputField, BorderLayout.CENTER);
        topPanel.add(clearButton, BorderLayout.EAST);

        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(equalsButton, BorderLayout.SOUTH);
    }

    private void addActionListeners() {
        for (int i = 0; i < 10; i++) {
            int number = i;
            numberButtons[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    inputField.setText(inputField.getText() + number);
                }
            });
        }

        operatorButtons[0].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstNumber = Double.parseDouble(inputField.getText());
                operator = "+";
                inputField.setText("");
            }
        });

        operatorButtons[1].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstNumber = Double.parseDouble(inputField.getText());
                operator = "-";
                inputField.setText("");
            }
        });

        operatorButtons[2].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstNumber = Double.parseDouble(inputField.getText());
                operator = "*";
                inputField.setText("");
            }
        });

        operatorButtons[3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstNumber = Double.parseDouble(inputField.getText());
                operator = "/";
                inputField.setText("");
            }
        });

        operatorButtons[4].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.sin(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[5].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.cos(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[6].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.tan(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[7].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.squareRoot(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[8].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.log(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[9].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.exp(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[10].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.square(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[11].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstNumber = Double.parseDouble(inputField.getText());
                operator = "^";
                inputField.setText("");
            }
        });

        operatorButtons[12].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstNumber = Double.parseDouble(inputField.getText());
                operator = "mod";
                inputField.setText("");
            }
        });

        operatorButtons[13].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inputField.setText(String.valueOf(Math.PI));
            }
        });

        operatorButtons[14].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inputField.setText(String.valueOf(Math.E));
            }
        });

        operatorButtons[15].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double number = Double.parseDouble(inputField.getText());
                double result = calculatorLogic.reciprocal(number);
                inputField.setText(String.valueOf(result));
            }
        });

        operatorButtons[16].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String input = inputField.getText();
                if (!input.isEmpty()) {
                    inputField.setText(input.substring(0, input.length() - 1));
                }
            }
        });

        operatorButtons[17].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inputField.setText("");
            }
        });

        equalsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double secondNumber = Double.parseDouble(inputField.getText());
                double result = 0;

                switch (operator) {
                    case "+":
                        result = calculatorLogic.add(firstNumber, secondNumber);
                        break;
                    case "-":
                        result = calculatorLogic.subtract(firstNumber, secondNumber);
                        break;
                    case "*":
                        result = calculatorLogic.multiply(firstNumber, secondNumber);
                        break;
                    case "/":
                        result = calculatorLogic.divide(firstNumber, secondNumber);
                        break;
                    case "^":
                        result = calculatorLogic.power(firstNumber, secondNumber);
                        break;
                    case "mod":
                        result = calculatorLogic.modulus(firstNumber, secondNumber);
                        break;
                }

                inputField.setText(String.valueOf(result));
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstNumber = 0;
                operator = "";
                inputField.setText("");
            }
        });
    }
}
