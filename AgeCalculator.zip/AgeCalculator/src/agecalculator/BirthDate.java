package agecalculator;

public class BirthDate extends CurrentDate implements LifeTime, UpcomingBirthday {

    protected short dayOfBirth;
    protected short monthOfBirth;
    protected short yearOfBirth;

    public BirthDate() {
    }

    public BirthDate(short dayOfBirth, short monthOfBirth, short yearOfBirth) {
        this.setYearOfBirth(yearOfBirth);
        this.setMonthOfBirth(monthOfBirth);
        this.setDayOfBirth(dayOfBirth);
    }

    public void setDayOfBirth(short dayOfBirth) {
        if (yearOfBirth == currentYear  && monthOfBirth >= currentMonth && dayOfBirth > currentDay) {
            System.out.println("You haven't been born yet I hope You never will");
            System.exit(1);
        } else if (dayOfBirth < 0) {
            idiotMassage();
            System.exit(1);
        } else if (dayOfBirth == 0) {
            sleptInClassMassage();
            System.exit(1);
        } else if (dayOfBirth > 29 && monthOfBirth == 2) {
            System.out.println("Invalid day");
            System.exit(1);
        } else if (dayOfBirth > 30 && !checkMonthOfBirth()) {
            System.out.println("Invalid day");
            System.exit(1);
        } else if ( dayOfBirth > 31 || dayOfBirth > 31 && checkMonthOfBirth()) {
            System.out.println("Invalid day");
            System.exit(1);
        } else {
            this.dayOfBirth = dayOfBirth;
        }
    }

    public void setMonthOfBirth(short monthOfBirth) {
        if (yearOfBirth == currentYear && monthOfBirth > currentMonth) {
            System.out.println("You haven't been born yet I hope You never will");
            System.exit(1);
        } else if (monthOfBirth < 0) {
            idiotMassage();
            System.exit(1);
        } else if (monthOfBirth == 0) {
            sleptInClassMassage();
            System.exit(1);
        } else if (monthOfBirth > 12) {
            System.out.println("Invalid moth");
            System.exit(1);
        } else {
            this.monthOfBirth = monthOfBirth;
        }
    }

    public void setYearOfBirth(short yearOfBirth) {
        if (yearOfBirth > currentYear) {
            System.out.println("You haven't been born yet I hope You never will");
            System.exit(1);
        } else if (yearOfBirth == 0) {
            sleptInClassMassage();
            System.exit(1);
        } else if (yearOfBirth < 0) {
            idiotMassage();
            System.exit(1);
        } else {
            this.yearOfBirth = yearOfBirth;
        }
    }

    public short getDayOfBirth() {
        return dayOfBirth;
    }

    public short getMonthOfBirth() {
        return monthOfBirth;
    }

    public short getYearOfBirth() {
        return yearOfBirth;
    }

    private boolean checkMonthOfBirth() {
        return monthOfBirth == 1 || monthOfBirth == 3 || monthOfBirth == 5 || monthOfBirth == 7 || monthOfBirth == 8 || monthOfBirth == 10 || monthOfBirth == 12;
    }

    private void sleptInClassMassage() {
        System.out.println("How can time be 0 what did they teach You in school, You were slipping in class didn't You");
    }

    private void idiotMassage() {
        System.out.println("Since when time is negative");
    }

    @Override
    public void nextBirthday() {
        System.out.println("Your next birthday is in " + calculateNextBirthMonth() + " months and " + calculateNextBirthDay() + "days \n");
    }

    public short calculateLivedDays() {
        short livingDays;
        if (dayOfBirth > currentDay) {
            livingDays = (short) ((currentDay + 30) - dayOfBirth);
        } else {
            livingDays = (short) (currentDay - dayOfBirth);
        }
        return livingDays;
    }

    public short calculateLivedMonth() {
        short livingMoth;
        if (monthOfBirth >= currentMonth) {
            if (dayOfBirth <= currentDay) {
                livingMoth = (short) ((currentMonth + 12) - monthOfBirth);
            } else {
                livingMoth = (short) (((currentMonth + 12) - monthOfBirth) - 1);
            }
        } else {
            if (dayOfBirth <= currentDay) {
                livingMoth = (short) (currentMonth - monthOfBirth);
            } else {
                livingMoth = (short) ((currentMonth - monthOfBirth) - 1);
            }
        }
        return livingMoth;
    }

    public short calculateLivedYears() {
        short livingYears;
        if (monthOfBirth > currentMonth) {
            livingYears = (short) ((currentYear - yearOfBirth) - 1);
        } else {
            livingYears = (short) (currentYear - yearOfBirth);
        }
        return livingYears;
    }

    public short calculateNextBirthMonth() {
        short nextBirthMonth;

        if (monthOfBirth >= currentMonth) {
            if (dayOfBirth >= currentDay) {
                 nextBirthMonth = (short) (monthOfBirth - currentMonth);
            } else {
                 nextBirthMonth = (short) ((monthOfBirth - currentMonth) - 1);
            }
        } else {
            if (dayOfBirth >= currentDay) {
                nextBirthMonth = (short) (12 - currentMonth + monthOfBirth);
            } else {
                nextBirthMonth = (short) ((12 - currentMonth) + (monthOfBirth - 1));
            }
        }
        
        return nextBirthMonth;
        
    }

    public short calculateNextBirthDay() {
        short nextBirthday;

        if (dayOfBirth >= currentDay) {
            nextBirthday = (short) (dayOfBirth - currentDay);
        } else {
            nextBirthday = (short) ((30 - currentDay) + dayOfBirth);
        }
        return nextBirthday;
    }

    @Override
    public void lifeDuration() {
        System.out.println("You are " + calculateLivedYears() + " Years " + calculateLivedMonth() + " Moth " + calculateLivedDays() + " Days old.\n");
    }

    public short getAgeInYears() {
        return calculateLivedYears();
    }

    public short getAgeInMonths() {
        return (short) (getAgeInYears() * 12 + calculateLivedMonth());
    }

    public int getAgeInDays() {
        return getAgeInMonths() * 30 + calculateLivedDays();
    }

    public int getAgeInWeeks() {
        return (getAgeInDays()) / 7;
    }

    public int getAgeInHours() {
        return getAgeInDays() * 24;
    }

    public long getAgeInMinutes() {
        return getAgeInHours() * 60;
    }

    public long getAgeInSeconds() {
        return getAgeInMinutes() * 60;
    }

    public void calculateAge() {
        System.out.println(
                "Your Age is: " + "\n"
                + "Total Years: " + getAgeInYears() + "\n"
                + "Total Months: " + getAgeInMonths() + "\n"
                + "Total Weeks: " + getAgeInWeeks() + "\n"
                + "Total Days: " + getAgeInDays() + "\n"
                + "Total Hours: " + getAgeInHours() + "\n"
                + "Total Minutes: " + getAgeInMinutes() + "\n"
                + "Total Seconds: " + getAgeInSeconds() + "\n");
    }

    @Override
    public String toString() {
        return "You are " + calculateLivedYears() + " Years " + calculateLivedMonth() + " Moth " + calculateLivedDays() + " Days old.\n";
    }

}
