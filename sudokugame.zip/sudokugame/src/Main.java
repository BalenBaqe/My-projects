public class Main {
    public static void main(String[] args) {
        SudokuGame sg = new SudokuGame();
        sg.playGame();
    }
}